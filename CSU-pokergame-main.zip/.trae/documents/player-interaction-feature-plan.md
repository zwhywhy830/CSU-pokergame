# 玩家互动功能实现方案

## Context

当前 CSU Poker Game 是本地人机对局（跑得快 + 骗子酒馆），用户希望在对局中向其他玩家发起互动：扔鸡蛋 / 送花 / 扔番茄，并配以音效与视觉反馈；同时支持快捷短语聊天（含音效）。AI 也应主动发起互动以让对局生动。

项目已具备完善的可复用基础设施：
- [AudioService.java](file:///e:/CSU-pokergame-main/src/main/java/com/csu/pokergame/audio/AudioService.java) 单例 + [SoundEffect.java](file:///e:/CSU-pokergame-main/src/main/java/com/csu/pokergame/audio/SoundEffect.java) 枚举，缺文件静默跳过
- [GameAnimationService.java](file:///e:/CSU-pokergame-main/src/main/java/com/cards/ui/effect/GameAnimationService.java) 提供 showToast / playButtonFeedback / 粒子层挂载
- [GameToast.java](file:///e:/CSU-pokergame-main/src/main/java/com/cards/ui/component/GameToast.java) 现成浮层气泡
- [ParticleEffect.java](file:///e:/CSU-pokergame-main/src/main/java/com/cards/ui/effect/ParticleEffect.java) 粒子工厂
- [PdkPlayerSeat.java](file:///e:/CSU-pokergame-main/src/main/java/com/cards/ui/pdk/PdkPlayerSeat.java) / [LiarPlayerSeat.java](file:///e:/CSU-pokergame-main/src/main/java/com/cards/ui/liar/LiarPlayerSeat.java) 现有座位组件
- app.css 暗色 token（`-color-bg`、`-color-accent`、`-color-danger` 等）

用户已确认：① 入口放在操作条旁边；② AI 主动发起互动；③ 合成 wav 音；④ 短语混合风格。

## 实现步骤

### 1. 扩展音效枚举与音频资源
**修改** [SoundEffect.java](file:///e:/CSU-pokergame-main/src/main/java/com/csu/pokergame/audio/SoundEffect.java) 新增 6 项：
```java
EGG_THROW("/audio/effect/egg_throw.wav"),
FLOWER_SEND("/audio/effect/flower_send.wav"),
TOMATO_THROW("/audio/effect/tomato_throw.wav"),
PHRASE_POSITIVE("/audio/effect/phrase_positive.wav"),
PHRASE_NEUTRAL("/audio/effect/phrase_neutral.wav"),
PHRASE_TAUNT("/audio/effect/phrase_taunt.wav");
```

**生成 6 个合成 wav**（44.1kHz / 单声道 / 16-bit PCM）放到 `src/main/resources/audio/effect/`：
- `egg_throw.wav`：220Hz 方波 + 白噪声衰减 0.15s（"啪嗒"）
- `tomato_throw.wav`：150Hz 三角波 0.18s（闷响 splat）
- `flower_send.wav`：660→990Hz 上升正弦 0.35s（柔和 chime）
- `phrase_positive.wav`：880Hz 正弦 0.12s（明亮 ping）
- `phrase_neutral.wav`：440Hz 正弦 0.10s（中性 ping）
- `phrase_taunt.wav`：200Hz 方波 0.20s（短 buzz）

用 PowerShell + .NET `BinaryWriter` 一次性生成所有文件。

### 2. 新建互动模型包 `com.csu.pokergame.interaction`

**新建** `InteractionType.java`：枚举每种互动的 emoji / 音效 / toast 文案 / 受击色调
```java
public enum InteractionType {
    EGG("\uD83E\uDD5A", SoundEffect.EGG_THROW, "被砸了鸡蛋！", Color.GOLD),  // 🥚
    FLOWER("\uD83C\uDF40", SoundEffect.FLOWER_SEND, "收到一束花！", Color.PINK),  // 🌸
    TOMATO("\uD83C\uDF45", SoundEffect.TOMATO_THROW, "被砸了番茄！", Color.TOMATO),  // 🍅
    PHRASE_POSITIVE(null, SoundEffect.PHRASE_POSITIVE, null, Color.GOLD),
    PHRASE_NEUTRAL(null, SoundEffect.PHRASE_NEUTRAL, null, Color.LIGHTGRAY),
    PHRASE_TAUNT(null, SoundEffect.PHRASE_TAUNT, null, Color.SALMON);
    // 字段：emoji、soundEffect、hitText、accentColor；并提供 isThrow() / isPhrase()
}
```

**新建** `QuickPhrase.java`：6 条混合风格短语
```java
public enum QuickPhrase {
    NICE_MOVE("承让了！", InteractionType.PHRASE_POSITIVE),
    GREAT_HAND("妙手！", InteractionType.PHRASE_POSITIVE),
    GG_666("666", InteractionType.PHRASE_POSITIVE),
    BAD_LUCK("运气真差", InteractionType.PHRASE_NEUTRAL),
    PLAY_AGAIN("再来一局", InteractionType.PHRASE_NEUTRAL),
    FAREWELL("告辞", InteractionType.PHRASE_TAUNT);
}
```

### 3. 新建互动服务 `InteractionService.java`（单例）
关键职责：
- `bind(Node tableRoot, Map<PlayerId, Node> seatAvatars, Pane fxLayer)` 注入牌桌根节点 / 各座位头像节点 / 动画层
- `fireInteraction(PlayerId source, PlayerId target, InteractionType type, String text)`：
  1. 在源座位头像场景坐标创建 emoji Label，加入 fxLayer
  2. 用 `TranslateTransition`（600ms，弧线轨迹靠关键帧插值）飞向目标座位头像
  3. 落地播放 `AudioService.getInstance().playEffect(type.soundEffect)`
  4. 在目标头像上方调 `GameToast.show(targetAvatar, text)` 显示气泡（互动用"🥚+被砸了鸡蛋！"，短语用原文）
  5. 给目标头像加 `TranslateTransition` 抖动（±4px，3 次，200ms）
- `maybeAiInteract(PlayerId aiPlayer, PlayerId humanPlayer)`：约 15% 概率发起互动，随机选 type/phrase，target=人类
- `clearTargetingMode()` / `enterTargetingMode(InteractionType, Consumer<PlayerId>)`：进入目标选择态时高亮可选座位（加 `.seat-targetable` 样式）

### 4. 新建 UI 组件 `PlayerInteractionBar.java`
位置：`com.cards.ui.component`，与 PdkActionBar 同包风格。
- 外部：`HBox` 含一个"💬 互动"主按钮（样式 `.interaction-trigger`）
- 点击主按钮 → 弹出 `VBox` popover（StackPane 浮层，挂在牌桌根上，类似 SettingsOverlay）：
  - 第一行：🥚 / 🌸 / 🍅 三个图标按钮，点击进入目标选择模式后关闭 popover
  - 第二行：6 个快捷短语按钮，点击直接发起广播（target 随机选一个 AI）
- API：
  - `Button getTriggerButton()`
  - `setOnInteractionChosen(Consumer<InteractionType>)`
  - `setOnPhraseChosen(Consumer<QuickPhrase>)`
  - `setOwnerRoot(StackPane root)` 用于挂载 popover

### 5. 接入跑得快牌桌 [PdkTableView.java](file:///e:/CSU-pokergame-main/src/main/java/com/csu/pokergame/ui/scene/PdkTableView.java)
- 在 `buildLayout()` 底部把 `handView` 和 `PlayerInteractionBar` 装入 `VBox`：
```java
VBox bottom = new VBox(8, handView, interactionBar);
table.setBottom(bottom);
```
- 给 `root` 添加透明 fxLayer（`Pane fxLayer = new Pane()` + `.liar-fx-layer` 样式）
- 把 `seat2.getAvatar()`、`seat3.getAvatar()` 注册进 InteractionService
- 给座位加 `setOnMouseClicked` 在 targeting 模式下作为目标回调
- `wireActions()` 中绑定 interactionBar 的回调 → 调 InteractionService.fireInteraction
- 在 `scheduleBotTurn` 末尾加 `interactionService.maybeAiInteract(bot, LOCAL)`

### 6. 接入骗子酒馆牌桌 [LiarTableView.java](file:///e:/CSU-pokergame-main/src/main/java/com/csu/pokergame/ui/scene/LiarTableView.java)（场景类）
- `com.cards.ui.liar.LiarTableView` 已自带 fxLayer（`getFxLayer()`）
- 场景类 `LiarTableView` 在 `buildLayout()` 中把 `liarView` 装入时，给底部 `VBox bottom = new VBox(8, liarView.getHandView(), liarView.getActionBar(), interactionBar)` —— 但 liarView 内部已有 Bottom 区，更稳的做法是在场景类最外层 BorderPane 加 Bottom：实际上场景类是把 `liarView` 整体放入 BorderPane center，所以应改为：
  - 在 `StackPane root` 之上叠加一个 `VBox` 浮层放在底部居中（StackPane.setAlignment(bottom, Pos.BOTTOM_CENTER)），里面放 `PlayerInteractionBar`
- 把 `liarView.getSeat(1..3).getAvatar()` 注册进 InteractionService，绑定 click 选择
- 在 `scheduleBotIfNeeded` 末尾加 `interactionService.maybeAiInteract(bot, LOCAL)`

### 7. CSS 样式（追加到 [app.css](file:///e:/CSU-pokergame-main/src/main/resources/com/csu/pokergame/ui/theme/app.css) 末尾）
```css
.interaction-bar { -fx-spacing: 14; -fx-alignment: center; -fx-padding: 6 0 0 0; }
.interaction-trigger { /* 暗底玻璃 + 金色描边主按钮 */ }
.interaction-popover { /* 暗玻璃面板 + 圆角 + 阴影 */ }
.interaction-btn-egg { -fx-text-fill: #ffd54f; }
.interaction-btn-flower { -fx-text-fill: #ff8fb1; }
.interaction-btn-tomato { -fx-text-fill: #ff6347; }
.interaction-phrase { /* 短语按钮 */ }
.seat-targetable { /* 可选目标高亮：金色虚线描边 + 呼吸 */ }
.seat-targetable:hover { -fx-border-color: #ffd54f; -fx-cursor: hand; }
.seat-hit { /* 受击瞬间红色光晕 */ }
.interaction-flyer { -fx-font-size: 28px; -fx-text-fill: white; }
```

### 8. 单测（可选轻量）
- `InteractionTypeTest`：验证 emoji / sound / 文案绑定
- `QuickPhraseTest`：验证 6 条短语都在
- 已有 `AudioServiceTest` 可加一项 `playEffect(SoundEffect.EGG_THROW)` 不抛异常（即使 wav 暂缺）

## 验证步骤
1. 运行 `mvnw javafx:run` 启动应用
2. 进入"跑得快"牌桌，应看到底部"💬 互动"按钮
3. 点击按钮 → popover 弹出 → 点 🥚 → 顶部 AI 座位出现金色虚线高亮 → 点击 AI1 → 鸡蛋 emoji 从玩家头像飞向 AI1 → 落地音效 + 红色抖动 + GameToast 显示"AI1 被砸了鸡蛋！"
4. 同样验证 🌸 / 🍅
5. 点击快捷短语"666" → 玩家头像位置弹出气泡 + ping 音效
6. 跑得快 AI 出牌后偶尔（约 15% 概率）主动发起互动反向操作玩家
7. 重复测试骗子酒馆牌桌
8. 在设置面板关闭音效总开关，再发起互动 → 应完全静默
9. 关闭动画总开关 → 飞行 emoji / 抖动跳过，但 toast 仍静态显示

## 关键文件清单
- 新建：`src/main/java/com/csu/pokergame/interaction/InteractionType.java`
- 新建：`src/main/java/com/csu/pokergame/interaction/QuickPhrase.java`
- 新建：`src/main/java/com/csu/pokergame/interaction/InteractionService.java`
- 新建：`src/main/java/com/cards/ui/component/PlayerInteractionBar.java`
- 修改：`src/main/java/com/csu/pokergame/audio/SoundEffect.java`
- 修改：`src/main/java/com/csu/pokergame/ui/scene/PdkTableView.java`
- 修改：`src/main/java/com/csu/pokergame/ui/scene/LiarTableView.java`
- 修改：`src/main/resources/com/csu/pokergame/ui/theme/app.css`
- 新增：`src/main/resources/audio/effect/{egg_throw,tomato_throw,flower_send,phrase_positive,phrase_neutral,phrase_taunt}.wav`
