package com.csu.pokergame.ui.scene;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import com.cards.ui.animation.SceneTransition;
import com.cards.ui.background.BackgroundManager;
import com.cards.ui.component.CoinBar;
import com.cards.ui.component.GrowthResultPanel;
import com.cards.ui.effect.GameAnimationService;
import com.cards.ui.effect.WinCelebration;
import com.cards.ui.liar.LiarActionBar;
import com.cards.ui.liar.LiarClaimPanel;
import com.cards.ui.liar.LiarHandView;
import com.cards.ui.liar.LiarPlayerSeat;
import com.cards.ui.liar.LiarRiskIndicator;
import com.csu.pokergame.audio.AudioService;
import com.csu.pokergame.audio.SoundEffect;
import com.csu.pokergame.core.card.Card;
import com.csu.pokergame.core.engine.GameCommand;
import com.csu.pokergame.core.engine.GameSnapshot;
import com.csu.pokergame.core.engine.PlayerId;
import com.csu.pokergame.core.player.BotDecision;
import com.csu.pokergame.core.player.RuleBotController;
import com.csu.pokergame.liarspoker.ChallengeDeclaration;
import com.csu.pokergame.liarspoker.DeclareLiarCards;
import com.csu.pokergame.liarspoker.GunState;
import com.csu.pokergame.liarspoker.LiarEngine;
import com.csu.pokergame.liarspoker.LiarPhase;
import com.csu.pokergame.liarspoker.LiarRandomPolicy;
import com.csu.pokergame.liarspoker.LiarResolution;
import com.csu.pokergame.liarspoker.LiarSnapshot;
import com.csu.pokergame.liarspoker.TrustDeclaration;
import com.csu.pokergame.player.Achievement;
import com.csu.pokergame.player.AchievementService;
import com.csu.pokergame.player.CoinService;
import com.csu.pokergame.player.GameRecordService;
import com.csu.pokergame.player.PlayerGrowthService;
import com.csu.pokergame.player.PlayerManager;
import com.csu.pokergame.ui.AppShell;
import com.cards.ui.component.PlayerInteractionBar;

import javafx.animation.PauseTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.BoxBlur;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.util.Duration;

/**
 * 骗子酒馆游戏桌（本地人机：SEAT_1 为玩家，SEAT_2/3/4 为机器人）。
 *
 * <p>阶段 10：用 deckapp-ui 的 Liar 组件（LiarTableView 容器 / LiarPlayerSeat /
 * LiarClaimPanel / LiarRiskIndicator / LiarHandView / LiarActionBar）替换原先
 * 简陋的 Label + CardView 实现，引擎交互逻辑（LiarEngine / LiarSnapshot /
 * DeclareLiarCards / bot 调度）保持不变。
 *
 * <p>座位映射（与容器 {@code getSeat(index)} 一致）：
 * index 0 = SEAT_1（本人，底部），1 = SEAT_2（AI1，顶部），
 * 2 = SEAT_3（AI2，左侧），3 = SEAT_4（AI3，右侧）。
 */
public final class LiarTableView extends BorderPane {

    private static final PlayerId LOCAL = PlayerId.SEAT_1;

    /** 入场费 / 胜负奖励（与跑得快同源，经 CoinService 写流水并落盘）。 */
    private static final int GAME_ENTRY_COST = 100;
    private static final int GAME_WIN_REWARD = 200;
    private static final int GAME_LOSS_REWARD = 50;
    private static final int LIAR_WIN_EXP = 50;
    private static final int LIAR_LOSS_EXP = 20;

    /** 座位顺序与容器 index 一一对应。 */
    private static final PlayerId[] SEAT_ORDER = {
            PlayerId.SEAT_1, PlayerId.SEAT_2, PlayerId.SEAT_3, PlayerId.SEAT_4
    };

    private final AppShell shell;
    private final LiarEngine engine;
    private final Map<PlayerId, RuleBotController> bots;

    /** 本人手牌选中下标集合（与 LiarHandView 内部选中态同步）。 */
    private final Set<Integer> selectedIndices = new LinkedHashSet<>();

    /** deckapp-ui 骗子酒馆容器（包名同类名，用全限定名区分）。 */
    private final com.cards.ui.liar.LiarTableView liarView =
            new com.cards.ui.liar.LiarTableView();

    /** 顶部金币栏（每帧与 CoinService 当前账号余额同步）。 */
    private final CoinBar liarCoinBar;

    /** 玩家互动按钮条（砸鸡蛋 / 送花 / 砸番茄 + 快捷短语）。 */
    private PlayerInteractionBar interactionBar;

    /** 本局是否已结算（防止重复结算 / 重复叠加结算层）。 */
    private boolean settled;

    // ----- 结算成长反馈字段 -----
    private boolean winForResult;
    private int goldDeltaForResult;
    private int expGainForResult;
    private PlayerGrowthService.LevelUpResult growthForResult;
    private final List<Achievement> achievementsForResult = new ArrayList<>();

    public LiarTableView(AppShell shell) {
        this.shell = shell;
        this.engine = new LiarEngine(new Random());
        this.engine.start();
        // 三个 AI：每个都独立随机决定是否质疑（50/50），让对局更不可预测
        this.bots = Map.of(
                PlayerId.SEAT_2, new RuleBotController(new LiarRandomPolicy(new Random())),
                PlayerId.SEAT_3, new RuleBotController(new LiarRandomPolicy(new Random())),
                PlayerId.SEAT_4, new RuleBotController(new LiarRandomPolicy(new Random())));

        this.liarCoinBar = liarView.getCoinBar();
        // 入场费：每局重新收取（与跑得快同源），扣完同步金币栏显示实时余额
        CoinService.getInstance().costGold(GAME_ENTRY_COST, "骗子酒馆入场");
        liarCoinBar.setCoins(CoinService.getInstance().getGold());

        // 座位名 / 等级：本人用真实等级，三家 AI 固定 8 级
        setupSeatProfiles();

        buildLayout();
        wireActions();
        refresh();
        GameAnimationService.getInstance().installButtonFeedback(this);
    }

    private void buildLayout() {
        // 背景层
        BackgroundManager.Background bg = BackgroundManager.createGameBackground();

        // 顶部：返回 + 设置
        Button back = new Button("← 返回模式选择");
        back.setOnAction(e -> shell.transitionTo("mode-choice", SceneTransition.Type.RETURN_LOBBY));
        Button settings = new Button("设置");
        settings.setOnAction(e -> shell.openSettings());
        HBox topBar = new HBox(12, back, settings);
        topBar.setAlignment(Pos.CENTER_LEFT);
        topBar.setPadding(new Insets(8, 12, 8, 12));

        // 组装：背景 + 角落花色水印 + 顶栏 + 骗子酒馆容器
        StackPane root = new StackPane(bg.root());
        addCornerSuit(root, "♠", Color.rgb(255, 255, 255, 0.05), Pos.TOP_LEFT, true);
        addCornerSuit(root, "♥", Color.rgb(255, 170, 160, 0.05), Pos.TOP_RIGHT, true);
        addCornerSuit(root, "♣", Color.rgb(255, 255, 255, 0.05), Pos.BOTTOM_LEFT, true);
        addCornerSuit(root, "♦", Color.rgb(255, 170, 160, 0.05), Pos.BOTTOM_RIGHT, true);
        root.getChildren().add(new BorderPane(topBar, liarView, null, null, null));

        // 互动按钮条：浮在牌桌底部居中（不抢占 liarView 底部 ActionBar 空间）
        interactionBar = new PlayerInteractionBar(root);
        StackPane.setAlignment(interactionBar, Pos.BOTTOM_CENTER);
        StackPane.setMargin(interactionBar, new Insets(0, 0, 8, 0));
        root.getChildren().add(interactionBar);

        // 注入互动服务：座位头像 + 座位根 + 名字（liarView 已自带 fxLayer）
        Map<PlayerId, Node> avatars = new HashMap<>();
        Map<PlayerId, Node> roots = new HashMap<>();
        Map<PlayerId, String> names = new HashMap<>();
        for (int i = 0; i < SEAT_ORDER.length; i++) {
            PlayerId p = SEAT_ORDER[i];
            LiarPlayerSeat seat = liarView.getSeat(i);
            if (seat == null) {
                continue;
            }
            avatars.put(p, seat.getAvatar());
            roots.put(p, seat);
            names.put(p, name(p));
        }
        InteractionService.getInstance().bind(liarView.getFxLayer(), avatars, roots, names);

        setCenter(root);
    }

    /** 座位名 / 等级：本人用真实等级，三家 AI 固定 8 级（与 deckapp-ui 一致）。 */
    private void setupSeatProfiles() {
        int userLevel = PlayerManager.getInstance().getProfile().getLevel();
        String[] names = {"你", "西家", "北家", "东家"};
        int[] levels = {userLevel, 8, 8, 8};
        for (int i = 0; i < SEAT_ORDER.length; i++) {
            LiarPlayerSeat seat = liarView.getSeat(i);
            if (seat == null) {
                continue;
            }
            seat.setPlayerName(names[i]);
            seat.setLevel(levels[i]);
        }
    }

    /** 在背景四角叠加花色水印（watermark=true 时加微模糊作为暗纹底）。 */
    private void addCornerSuit(StackPane root, String g, Color color, Pos corner, boolean watermark) {
        Label l = new Label(g);
        l.setTextFill(color);
        l.setFont(Font.font("Segoe UI Symbol", 150));
        l.getStyleClass().add("menu-corner");
        l.setMouseTransparent(true);
        if (watermark) {
            l.setEffect(new BoxBlur(4, 4, 3));
        }
        StackPane.setAlignment(l, corner);
        Insets m = switch (corner) {
            case TOP_LEFT -> new Insets(8, 0, 0, 26);
            case TOP_RIGHT -> new Insets(8, 26, 0, 0);
            case BOTTOM_LEFT -> new Insets(0, 0, 10, 26);
            default -> new Insets(0, 26, 10, 0);
        };
        StackPane.setMargin(l, m);
        root.getChildren().add(l);
    }

    private void wireActions() {
        LiarHandView hand = liarView.getHandView();
        hand.setMaxSelect(3);
        hand.setOnSelectionChange(sel -> {
            selectedIndices.clear();
            selectedIndices.addAll(sel);
            refreshActions();
        });

        LiarActionBar bar = liarView.getActionBar();
        bar.getDeclareButton().setOnAction(e -> declare());
        bar.getContinueButton().setOnAction(e -> trust());
        bar.getChallengeButton().setOnAction(e -> challenge());

        // 互动按钮：投掷类进入目标选择；短语类直接广播
        interactionBar.setOnInteractionChosen(type ->
                InteractionService.getInstance().enterTargetingMode(
                        type,
                        Set.of(PlayerId.SEAT_2, PlayerId.SEAT_3, PlayerId.SEAT_4),
                        target -> InteractionService.getInstance()
                                .fireInteraction(LOCAL, target, type, null)));
        interactionBar.setOnPhraseChosen(phrase ->
                InteractionService.getInstance().fireInteraction(
                        LOCAL, LOCAL, phrase.getType(), phrase.getText()));
    }

    private void refresh() {
        LiarSnapshot snap = (LiarSnapshot) engine.snapshotFor(LOCAL);

        // 金币栏：每帧与当前账号余额对齐（充值 / 商城 / 换账号后不残留旧数字）
        liarCoinBar.setCoins(CoinService.getInstance().getGold());

        // 顶部：阶段 / 存活 / 目标点数 + 入场费
        liarView.setPhaseText(phaseName(snap.liarPhase()));
        liarView.setAliveText(snap.alivePlayers().size());
        liarView.setTipText("目标点数：" + snap.targetRank().label() + " · 入场 " + GAME_ENTRY_COST);

        // 四家座位：生命值 + 状态
        renderSeats(snap);

        // 中央声明卡 + 顶部紧凑声明
        renderClaim(snap);

        // 怀疑度（纯展示，按已宣告张数粗略估算）
        LiarRiskIndicator risk = liarView.getRiskIndicator();
        risk.setValue(snap.pendingDeclaredCount() > 0
                ? Math.min(1.0, snap.pendingDeclaredCount() / 3.0 * 0.7 + 0.1)
                : 0.0);

        // 本人手牌
        LiarHandView hand = liarView.getHandView();
        hand.setCards(snap.myHand());
        selectedIndices.removeIf(i -> i >= snap.myHand().size());
        hand.refreshSelection();

        // 日志（最新在上，与原实现一致）
        List<String> events = new ArrayList<>(snap.publicEvents());
        java.util.Collections.reverse(events);
        liarView.setLogEntries(events);

        if (snap.winner().isPresent()) {
            renderResult(snap);
            return;
        }

        refreshActions();
        scheduleBotIfNeeded(snap);
    }

    private void renderSeats(LiarSnapshot snap) {
        for (int i = 0; i < SEAT_ORDER.length; i++) {
            PlayerId p = SEAT_ORDER[i];
            LiarPlayerSeat seat = liarView.getSeat(i);
            if (seat == null) {
                continue;
            }
            seat.setPlayerName(name(p));

            GunState gun = snap.guns().get(p);
            int pulled = gun == null ? 0 : gun.shotsFired();
            // 生命值按「剩余机会」折算成 0~3 颗心
            seat.setLife(Math.max(0, 3 - pulled / 2));

            if (snap.eliminatedPlayers().contains(p)) {
                seat.setDead();
            } else if (snap.winner().isPresent()) {
                seat.setNormal();
                if (snap.winner().get() == p) {
                    seat.playWinBurst();
                }
            } else if (p == snap.currentPlayer()) {
                seat.setThinking();
            } else {
                seat.setNormal();
            }
        }
    }

    private void renderClaim(LiarSnapshot snap) {
        LiarClaimPanel center = liarView.getClaimPanel();
        LiarClaimPanel header = liarView.getHeaderClaim();

        String declarerName = snap.declarer() == null ? "" : name(snap.declarer());
        String claimText = snap.declarer() == null
                ? "等待首位宣告者"
                : snap.pendingDeclaredCount() + " 张 " + snap.targetRank().label();

        center.setDeclarer(declarerName);
        center.setClaim(claimText);
        center.setCredibilityUnknown();

        header.setDeclarer(declarerName);
        header.setClaim(claimText);
        header.setCredibilityUnknown();
    }

    private void refreshActions() {
        LiarSnapshot snap = (LiarSnapshot) engine.snapshotFor(LOCAL);
        LiarActionBar bar = liarView.getActionBar();
        LiarHandView hand = liarView.getHandView();

        boolean myTurn = snap.currentPlayer() == LOCAL;
        // 手牌只在「本人 · 宣告阶段」可点击选牌
        hand.setInteractive(myTurn && snap.liarPhase() == LiarPhase.DECLARE);

        if (!myTurn) {
            bar.setAllEnabled(false);
            return;
        }
        if (snap.liarPhase() == LiarPhase.DECLARE) {
            bar.setDeclareEnabled(!selectedCards(snap).isEmpty());
            bar.setContinueEnabled(false);
            bar.setChallengeEnabled(false);
        } else if (snap.liarPhase() == LiarPhase.RESPOND) {
            bar.setDeclareEnabled(false);
            bar.setContinueEnabled(true);
            bar.setChallengeEnabled(true);
        } else {
            bar.setAllEnabled(false);
        }
    }

    /** 把选中的手牌下标映射为实际牌（顺序与快照手牌一致）。 */
    private List<Card> selectedCards(LiarSnapshot snap) {
        List<Card> hand = snap.myHand();
        List<Card> picked = new ArrayList<>();
        for (int i : selectedIndices) {
            if (i >= 0 && i < hand.size()) {
                picked.add(hand.get(i));
            }
        }
        return picked;
    }

    private void declare() {
        LiarSnapshot snap = (LiarSnapshot) engine.snapshotFor(LOCAL);
        List<Card> picked = selectedCards(snap);
        if (picked.isEmpty() || picked.size() > 3) {
            return;
        }
        engine.apply(new DeclareLiarCards(picked));
        selectedIndices.clear();
        liarView.getHandView().clearSelection();
        liarView.getClaimPanel().playClaimIn();
        refresh();
    }

    private void trust() {
        engine.apply(new TrustDeclaration());
        selectedIndices.clear();
        liarView.getHandView().clearSelection();
        refresh();
    }

    private void challenge() {
        engine.apply(new ChallengeDeclaration());
        selectedIndices.clear();
        liarView.getHandView().clearSelection();
        liarView.playChallengeEffect();
        refresh();
    }

    private void scheduleBotIfNeeded(LiarSnapshot snap) {
        if (snap.currentPlayer() == LOCAL) {
            return;
        }
        PlayerId bot = snap.currentPlayer();
        // AI 每步操作间停顿 1 秒，让玩家能看清上家宣告 / 质疑节奏
        PauseTransition pause = new PauseTransition(Duration.millis(1000));
        pause.setOnFinished(e -> {
            GameSnapshot botSnap = engine.snapshotFor(bot);
            List<GameCommand> legal = engine.legalCommands(bot);
            if (legal.isEmpty()) {
                refresh();
                return;
            }
            BotDecision decision = bots.get(bot).decide(botSnap, legal);
            engine.apply(decision.command());
            refresh();
            // AI 偶尔向玩家发起互动（约 15% 概率）
            InteractionService.getInstance()
                    .maybeAiInteract(bot, LOCAL, List.of(LOCAL));
        });
        pause.play();
    }

    private void renderResult(LiarSnapshot snap) {
        if (settled) {
            return;
        }
        settled = true;

        boolean localWon = snap.winner().orElseThrow() == LOCAL;
        if (localWon) {
            liarView.playVictoryGlow();
        } else {
            liarView.playDefeatEffect();
        }

        // 金币结算：胜/负奖励 + 音效（与跑得快同源，唯一入口 CoinService）
        settleLiar(localWon);

        // 副标题：复用原结算原因文案
        String subtitle;
        if (snap.lastResolution().isPresent()) {
            LiarResolution res = snap.lastResolution().get();
            if (res.shooter() == LOCAL && res.killed()) {
                subtitle = "你扣扳机打中子弹仓，被淘汰";
            } else if (!localWon) {
                subtitle = name(snap.winner().orElseThrow()) + " 是最后存活者";
            } else {
                subtitle = "你是最后存活者";
            }
        } else {
            subtitle = localWon ? "你是最后存活者" : name(snap.winner().orElseThrow()) + " 是最后存活者";
        }

        // 终局庆祝层：胜利金色星光 / 失败灰化 + 成长反馈面板
        javafx.scene.Node growthPanel = buildGrowthPanel();

        final WinCelebration[] celebrationRef = new WinCelebration[1];

        Button again = new Button("重新开始");
        again.getStyleClass().addAll("menu-btn", "result-btn", "result-btn-restart");
        again.setOnAction(e -> {
            celebrationRef[0].stop();
            shell.transitionTo("liar", SceneTransition.Type.ENTER_GAME);
        });
        Button back = new Button("返回游戏选择");
        back.getStyleClass().addAll("menu-btn", "result-btn", "result-btn-back");
        back.setOnAction(e -> {
            celebrationRef[0].stop();
            shell.transitionTo("mode-choice", SceneTransition.Type.RETURN_LOBBY);
        });
        HBox buttons = new HBox(22, again, back);
        buttons.setAlignment(Pos.CENTER);

        celebrationRef[0] = new WinCelebration(localWon, subtitle, growthPanel, buttons);

        StackPane root = (StackPane) getCenter();
        root.getChildren().add(celebrationRef[0]);

        // 结算表现动画
        GameAnimationService anim = GameAnimationService.getInstance();
        if (localWon) {
            anim.playWinAnimation(root, celebrationRef[0]);
        } else {
            anim.playLoseAnimation(celebrationRef[0]);
        }
        boolean upgraded = growthForResult != null && growthForResult.upgraded();
        PauseTransition settleDelay = new PauseTransition(Duration.millis(140));
        settleDelay.setOnFinished(e -> {
            javafx.scene.Node coinTarget = liarCoinBar != null ? liarCoinBar : celebrationRef[0];
            anim.playCoinAnimation(growthPanel, coinTarget, null);
            if (upgraded) {
                anim.playLevelUpAnimation(growthPanel);
            }
            anim.showToast(celebrationRef[0], settleToastText(upgraded));
        });
        settleDelay.play();
    }

    /**
     * 本局结算：胜/负奖励经 {@link CoinService} 写入当前账号并落盘，并播放对应音效。
     */
    private void settleLiar(boolean win) {
        CoinService coinService = CoinService.getInstance();
        int goldDelta = win ? GAME_WIN_REWARD : GAME_LOSS_REWARD;
        int expGain = win ? LIAR_WIN_EXP : LIAR_LOSS_EXP;
        coinService.addGold(goldDelta, win ? "骗子酒馆胜利奖励" : "骗子酒馆参与奖励");

        // 加经验并自动升级
        PlayerGrowthService growthService = PlayerGrowthService.getInstance();
        growthForResult = growthService.addExp(expGain);

        // 战绩统计
        com.csu.pokergame.player.PlayerStatsService.getInstance().recordGameResult(win);

        // 战绩明细
        GameRecordService.getInstance().addRecord(
                "骗子酒馆", win, goldDelta, expGain, GameRecordService.OPPONENT_AI);

        // 成就检测
        if (win) {
            achievementsForResult.addAll(AchievementService.getInstance().checkOnWin());
        }
        achievementsForResult.addAll(AchievementService.getInstance().checkOnGoldChange());
        achievementsForResult.addAll(AchievementService.getInstance().checkOnLevelUp());

        // 记录本局成长反馈
        winForResult = win;
        goldDeltaForResult = goldDelta;
        expGainForResult = expGain;

        liarCoinBar.setCoins(coinService.getGold());
        AudioService.getInstance()
                .playEffect(win ? SoundEffect.WIN : SoundEffect.LOSE);
    }

    /** 构建骗子酒馆结算成长反馈面板。 */
    private javafx.scene.Node buildGrowthPanel() {
        PlayerProfile profile = PlayerManager.getInstance().getProfile();
        PlayerGrowthService growthService = PlayerGrowthService.getInstance();
        int level = profile.getLevel();
        GrowthResultPanel panel = new GrowthResultPanel(
                winForResult,
                goldDeltaForResult,
                expGainForResult,
                level,
                growthService.getLevelTitle(level),
                growthService.getLevelBadge(level),
                profile.getExp(),
                growthService.expToNextLevel(level),
                growthForResult);
        if (achievementsForResult.isEmpty()) {
            return panel;
        }
        VBox box = new VBox(10, panel, buildAchievementNotice());
        box.setAlignment(Pos.CENTER);
        return box;
    }

    /** 本局解锁的成就提示条。 */
    private VBox buildAchievementNotice() {
        VBox box = new VBox(6);
        box.setAlignment(Pos.CENTER);
        for (Achievement a : achievementsForResult) {
            Label label = new Label("🏆 成就解锁：" + a.getTitle()
                    + "　奖励 +" + a.getRewardGold() + " 金币 / +" + a.getRewardExp() + " 经验");
            label.getStyleClass().add("growth-result-achievement");
            box.getChildren().add(label);
        }
        return box;
    }

    /** 结算提示条文案。 */
    private String settleToastText(boolean upgraded) {
        StringBuilder msg = new StringBuilder();
        msg.append("＋").append(goldDeltaForResult).append(" 金币")
                .append(" · ＋").append(expGainForResult).append(" 经验");
        if (upgraded && growthForResult != null) {
            msg.append(" · ✨ Level UP Lv.").append(growthForResult.getOldLevel())
                    .append(" → Lv.").append(growthForResult.getNewLevel());
        }
        if (!achievementsForResult.isEmpty()) {
            msg.append(" · 🏆 ").append(achievementsForResult.get(0).getTitle());
        }
        return msg.toString();
    }

    private static String phaseName(LiarPhase phase) {
        return switch (phase) {
            case DECLARE -> "宣告";
            case RESPOND -> "回应";
            case RESOLVE -> "结算";
            case FINISHED -> "结束";
        };
    }

    private static String name(PlayerId p) {
        return switch (p) {
            case SEAT_1 -> "你";
            case SEAT_2 -> "西家";
            case SEAT_3 -> "北家";
            case SEAT_4 -> "东家";
        };
    }
}
